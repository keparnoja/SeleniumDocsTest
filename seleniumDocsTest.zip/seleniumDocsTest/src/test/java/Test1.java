import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Test1 {//should submit correct way
    public static void main(String[] args) {
        ExtentHtmlReporter extentHtmlReporter = new ExtentHtmlReporter("extentReports.html");
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(extentHtmlReporter);
        ExtentTest test1 = extent.createTest("docs test 1");

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\kepar\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        test1.log(Status.INFO, "Starting Test Case");
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        driver.get("https://docs.google.com/forms/d/e/1FAIpQLScVG7idLWR8sxNQygSnLuhehUNVFti0FnVviWCSjD\n" +
                "h-JNhsMA/viewform?usp=sf_link");
        test1.pass("Navigated to google docs");


        WebElement option3 = driver.findElement(By.id("i11"));//3rd option
        option3.click();
        test1.pass("clicked option 3");
        driver.findElement(By.cssSelector("#mG61Hd > div.RH5hzf.RLS9Fe > div > div.o3Dpx > div:nth-child(2) > div > div > div.AgroKb > div > div.aCsJod.oJeWuf > div > div.Xb9hP > input")).sendKeys("Karl Erik Pärnoja");
        test1.pass("name was entered");
        driver.findElement(By.cssSelector("#mG61Hd > div.RH5hzf.RLS9Fe > div > div.o3Dpx > div:nth-child(3) > div > div > div.AgroKb > div > div.aCsJod.oJeWuf > div > div.Xb9hP > input")).sendKeys("Keparnoja@gmail.com");
        test1.pass("email was entered");
        driver.findElement(By.cssSelector("#mG61Hd > div.RH5hzf.RLS9Fe > div > div.o3Dpx > div:nth-child(4) > div > div > div.AgroKb > div > div.RpC4Ne.oJeWuf > div.Pc9Gce.Wic03c > textarea")).sendKeys("Estonia, Tallinn");
        test1.pass("address was entered");
        driver.findElement(By.cssSelector("#mG61Hd > div.RH5hzf.RLS9Fe > div > div.o3Dpx > div:nth-child(5) > div > div > div.AgroKb > div > div.aCsJod.oJeWuf > div > div.Xb9hP > input")).sendKeys("55555555");
        test1.pass("phone number was entered");
        driver.findElement(By.cssSelector("#mG61Hd > div.RH5hzf.RLS9Fe > div > div.o3Dpx > div:nth-child(6) > div > div > div.AgroKb > div > div.RpC4Ne.oJeWuf > div.Pc9Gce.Wic03c > textarea")).sendKeys("this one selects 3rd option and completes everything");
        test1.pass("comments were entered");
        driver.findElement(By.cssSelector("#mG61Hd > div.RH5hzf.RLS9Fe > div > div.ThHDze > div.DE3NNc.CekdCb > div.lRwqcd > div > span")).click();
        test1.pass("clicked submit button");
        String link = driver.getCurrentUrl();


        if(link.equals("https://docs.google.com/forms/d/e/1FAIpQLScVG7idLWR8sxNQygSnLuhehUNVFti0FnVviWCSjDh-JNhsMA/formResponse")){
            System.out.println("everything worked");
            test1.pass("everything worked");
        }
        else{
            test1.pass("some important data was missing");
        }
        driver.close();
        driver.quit();
        test1.info("Test Completed");
        extent.flush();
    }
}
