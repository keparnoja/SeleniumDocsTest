import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Test2 {//Should fail
    public static void main(String[] args) {

        ExtentHtmlReporter extentHtmlReporter = new ExtentHtmlReporter("extentReports.html");
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(extentHtmlReporter);
        ExtentTest test2 = extent.createTest("docs test 2");

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\kepar\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
        driver.get("https://docs.google.com/forms/d/e/1FAIpQLScVG7idLWR8sxNQygSnLuhehUNVFti0FnVviWCSjD\n" +
                "h-JNhsMA/viewform?usp=sf_link");
        test2.pass("Navigated to google docs");
        WebElement option3 = driver.findElement(By.id("i11"));//3rd option
        option3.click();
        test2.pass("clicked option 3");
        driver.findElement(By.cssSelector("#mG61Hd > div.RH5hzf.RLS9Fe > div > div.o3Dpx > div:nth-child(4) > div > div > div.AgroKb > div > div.RpC4Ne.oJeWuf > div.Pc9Gce.Wic03c > textarea")).sendKeys("Estonia, Tallinn");
        test2.pass("Entered location");
        driver.findElement(By.cssSelector("#mG61Hd > div.RH5hzf.RLS9Fe > div > div.o3Dpx > div:nth-child(5) > div > div > div.AgroKb > div > div.aCsJod.oJeWuf > div > div.Xb9hP > input")).sendKeys("55555555");
        test2.pass("Entered phone number");
        driver.findElement(By.cssSelector("#mG61Hd > div.RH5hzf.RLS9Fe > div > div.o3Dpx > div:nth-child(6) > div > div > div.AgroKb > div > div.RpC4Ne.oJeWuf > div.Pc9Gce.Wic03c > textarea")).sendKeys("this one selects 3rd option and completes everything");
        test2.pass("Comments were entered");
        driver.findElement(By.cssSelector("#mG61Hd > div.RH5hzf.RLS9Fe > div > div.ThHDze > div.DE3NNc.CekdCb > div.lRwqcd > div > span")).click();
        test2.pass("submit button were clicked");
        String link = driver.getCurrentUrl();

        if(link.equals("https://docs.google.com/forms/d/e/1FAIpQLScVG7idLWR8sxNQygSnLuhehUNVFti0FnVviWCSjDh-JNhsMA/formResponse")){
            System.out.println("everything worked");
            test2.pass("everything were entered correctly");
        }
        else{
            test2.fail("some important data was missing");
        }
        driver.close();
        driver.quit();
        test2.info("test Over");
        extent.flush();

    }
}
